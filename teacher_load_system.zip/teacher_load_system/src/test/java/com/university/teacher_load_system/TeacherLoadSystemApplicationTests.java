package com.university.teacher_load_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherLoadSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
