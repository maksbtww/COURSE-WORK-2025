package com.university.teacher_load_system.service;

import com.university.teacher_load_system.entity.Teacher;
import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    private final TeacherRepository repository;

    public TeacherService(TeacherRepository repository) {
        this.repository = repository;
    }

    // Получить всех преподавателей
    public List<Teacher> findAll() {
        return repository.findAll();
    }

    // Найти по ID
    public Teacher findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    // Найти преподавателя по пользователю
    public Teacher findByUser(User user) {
        return repository.findByUser(user);
    }

    // Найти преподавателей по кафедре
    public List<Teacher> findByDepartment(String department) {
        return repository.findByDepartment(department);
    }

    // Сохранить или обновить преподавателя
    public void save(Teacher teacher) {
        repository.save(teacher);
    }

    // Удалить преподавателя
    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    // 🔍 Поиск по ФИО преподавателя
    public List<Teacher> findByUserFullNameContainingIgnoreCase(String fullName) {
        return repository.findByUser_FullNameContainingIgnoreCase(fullName);
    }

}