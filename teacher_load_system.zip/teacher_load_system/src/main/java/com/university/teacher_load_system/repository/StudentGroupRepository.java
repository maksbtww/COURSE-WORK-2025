package com.university.teacher_load_system.repository;

import com.university.teacher_load_system.entity.StudentGroup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StudentGroupRepository extends JpaRepository<StudentGroup, Long> {
    List<StudentGroup> findByCodeContainingIgnoreCase(String code);
}