package com.university.teacher_load_system.repository;

import com.university.teacher_load_system.entity.Teacher;
import com.university.teacher_load_system.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeacherRepository extends JpaRepository<Teacher, Long> {
    Teacher findByUser(User user);
    List<Teacher> findByDepartment(String department);
    List<Teacher> findByUser_FullNameContainingIgnoreCase(String fullName);
}