package com.university.teacher_load_system.controller.api;

import com.university.teacher_load_system.entity.Discipline;
import com.university.teacher_load_system.service.DisciplineService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/disciplines")
public class DisciplineApiController {

    private final DisciplineService disciplineService;

    public DisciplineApiController(DisciplineService disciplineService) {
        this.disciplineService = disciplineService;
    }

    @GetMapping("/search")
    public List<Discipline> searchDisciplines(@RequestParam String query) {
        if (query == null || query.isBlank()) {
            return disciplineService.findAll();
        }
        return disciplineService.findByNameContainingIgnoreCase(query);
    }
}