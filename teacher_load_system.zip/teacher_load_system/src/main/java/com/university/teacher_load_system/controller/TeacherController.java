package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.Teacher;
import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.repository.TeacherRepository;
import com.university.teacher_load_system.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/teachers")
public class TeacherController {

    private final TeacherRepository teacherRepository;
    private final UserRepository userRepository;

    public TeacherController(TeacherRepository teacherRepository,
                             UserRepository userRepository) {
        this.teacherRepository = teacherRepository;
        this.userRepository = userRepository;
    }

    // Показать список преподавателей
    @GetMapping
    public String listTeachers(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        List<Teacher> teachers = teacherRepository.findAll();
        model.addAttribute("teachers", teachers);
        model.addAttribute("currentUser", currentUser);
        return "teachers";
    }

    // Показать форму добавления
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("teacher", new Teacher());
        return "admin/teacher-form";
    }

    // Сохранить нового или обновить существующего
    @PostMapping("/add")
    public String saveTeacher(@ModelAttribute Teacher teacher,
                              @RequestParam String fullName) {

        if (teacher.getId() == null) {
            // Добавление нового преподавателя
            User newUser = new User();
            newUser.setFullName(fullName);
            newUser.setUsername(generateUniqueUsername(fullName));
            newUser.setPassword("default");
            newUser.setRole("teacher");

            User savedUser = userRepository.save(newUser);
            teacher.setUser(savedUser);

        } else {
            // Обновление существующего
            Teacher existingTeacher = teacherRepository.findById(teacher.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Преподаватель не найден"));

            User user = existingTeacher.getUser();
            if (user != null) {
                user.setFullName(fullName);
                user.setUsername(generateUniqueUsername(fullName));
                userRepository.save(user);

                existingTeacher.setDepartment(teacher.getDepartment());
                existingTeacher.setPosition(teacher.getPosition());

                teacher = existingTeacher;
            }
        }

        teacherRepository.save(teacher);
        return "redirect:/teachers";
    }

    // Показать форму редактирования
    @GetMapping("/edit")
    public String editTeacherForm(@RequestParam("id") Long id, Model model) {
        Teacher teacher = teacherRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Преподаватель не найден"));
        model.addAttribute("teacher", teacher);
        return "admin/teacher-form";
    }

    // Удаление преподавателя
    @GetMapping("/delete/{id}")
    public String deleteTeacher(@PathVariable Long id) {
        teacherRepository.deleteById(id);
        return "redirect:/teachers";
    }

    // Генерация уникального username
    private String generateUniqueUsername(String fullName) {
        String base = extractSurname(fullName);
        String username = base;
        int counter = 1;

        while (userRepository.findByUsername(username) != null) {
            username = base + counter;
            counter++;
        }

        return username;
    }

    private String extractSurname(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            return "default";
        }

        String[] parts = fullName.trim().split("\\s+");
        return parts[0].toLowerCase(); // только фамилия
    }
}