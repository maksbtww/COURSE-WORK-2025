package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.Discipline;
import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.repository.DisciplineRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/disciplines")
public class DisciplineController {

    private final DisciplineRepository disciplineRepository;

    public DisciplineController(DisciplineRepository disciplineRepository) {
        this.disciplineRepository = disciplineRepository;
    }

    @GetMapping
    public String listDisciplines(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || (!"admin".equals(currentUser.getRole()) && !"head_of_dept".equals(currentUser.getRole()))) {
            return "redirect:/login";
        }

        List<Discipline> disciplines = disciplineRepository.findAll();
        model.addAttribute("disciplines", disciplines);
        model.addAttribute("currentUser", currentUser);
        return "disciplines";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("discipline", new Discipline());
        return "admin/discipline-form";
    }

    @PostMapping("/add")
    public String saveDiscipline(@ModelAttribute Discipline discipline) {
        disciplineRepository.save(discipline);
        return "redirect:/disciplines";
    }

    @GetMapping("/edit")
    public String editDisciplineForm(@RequestParam("id") Long id, Model model) {
        Discipline discipline = disciplineRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Дисциплина не найдена"));
        model.addAttribute("discipline", discipline);
        return "admin/discipline-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteDiscipline(@PathVariable Long id, Model model) {
        try {
            disciplineRepository.deleteById(id);
        } catch (Exception e) {
            model.addAttribute("error", "Невозможно удалить дисциплину: она используется в других данных.");
            List<Discipline> disciplines = disciplineRepository.findAll();
            model.addAttribute("disciplines", disciplines);
            return "disciplines";
        }
        return "redirect:/disciplines";
    }
}