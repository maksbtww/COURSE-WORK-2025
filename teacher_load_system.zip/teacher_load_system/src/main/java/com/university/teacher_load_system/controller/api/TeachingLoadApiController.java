package com.university.teacher_load_system.controller.api;

import com.university.teacher_load_system.entity.TeachingLoad;
import com.university.teacher_load_system.service.TeachingLoadService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loads")
public class TeachingLoadApiController {

    private final TeachingLoadService teachingLoadService;

    public TeachingLoadApiController(TeachingLoadService teachingLoadService) {
        this.teachingLoadService = teachingLoadService;
    }

    @GetMapping("/search")
    public List<TeachingLoad> searchLoads(@RequestParam String query) {
        if (query == null || query.isBlank()) {
            return teachingLoadService.findAll();
        }
        return teachingLoadService.findByTeacherFullNameContainingIgnoreCase(query);
    }
}