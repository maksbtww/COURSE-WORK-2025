package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.entity.Teacher;
import com.university.teacher_load_system.repository.UserRepository;
import com.university.teacher_load_system.repository.TeacherRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserRepository userRepository;
    private final TeacherRepository teacherRepository;

    public UserController(UserRepository userRepository, TeacherRepository teacherRepository) {
        this.userRepository = userRepository;
        this.teacherRepository = teacherRepository;
    }

    // Отображение списка пользователей
    @GetMapping
    public String listUsers(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("currentUser", currentUser);
        return "users";
    }

    // Форма редактирования пользователя
    @GetMapping("/edit")
    public String editUserForm(@RequestParam("id") Long id,
                               Model model,
                               HttpSession session) {

        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        User userToEdit = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Пользователь не найден"));
        model.addAttribute("user", userToEdit);
        model.addAttribute("currentUser", currentUser);
        return "admin/user-form";
    }

    // Сохранение изменений
    @PostMapping("/update")
    public String updateUser(@RequestParam("id") Long id,
                             @RequestParam("fullName") String fullName,
                             @RequestParam("username") String username,
                             @RequestParam("role") String role,
                             @RequestParam(value = "password", required = false) String password,
                             HttpSession session,
                             Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        // Получаем текущего пользователя
        User userToUpdate = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Пользователь не найден"));

        // Проверяем, не занят ли новый логин другим пользователем
        User existingUser = userRepository.findByUsername(username);
        if (existingUser != null && !existingUser.getId().equals(userToUpdate.getId())) {
            model.addAttribute("error", "Пользователь с таким логином уже существует.");
            model.addAttribute("user", userToUpdate); // Сохраняем текущие данные для повторного отображения формы
            return "admin/user-form"; // Остаться на форме с ошибкой
        }

        // Обновляем данные
        userToUpdate.setFullName(fullName);
        userToUpdate.setUsername(username);
        userToUpdate.setRole(role);
        if (password != null && !password.isEmpty()) {
            userToUpdate.setPassword(password);
        }
        userRepository.save(userToUpdate);
        return "redirect:/users";
    }

    // Удаление пользователя
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
        }
        return "redirect:/users";
    }

    // Форма добавления пользователя
    @GetMapping("/add")
    public String addUserForm(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }
        model.addAttribute("user", new User());
        model.addAttribute("currentUser", currentUser);
        return "admin/user-form";
    }

    // Сохранение нового пользователя
    @PostMapping("/add")
    public String addUser(@RequestParam("fullName") String fullName,
                         @RequestParam("username") String username,
                         @RequestParam("role") String role,
                         @RequestParam(value = "password", required = false) String password,
                         Model model,
                         HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/login";
        }
        // Проверяем, не занят ли логин
        User existingUser = userRepository.findByUsername(username);
        if (existingUser != null) {
            User user = new User();
            user.setFullName(fullName);
            user.setUsername(username);
            user.setRole(role);
            model.addAttribute("error", "Пользователь с таким логином уже существует.");
            model.addAttribute("user", user);
            model.addAttribute("currentUser", currentUser);
            return "admin/user-form";
        }
        User user = new User();
        user.setFullName(fullName);
        user.setUsername(username);
        user.setRole(role);
        user.setPassword(password != null ? password : "default123");
        userRepository.save(user);
        // Всегда создаём сущность Teacher с позицией 'Преподаватель' для любого пользователя
        Teacher teacher = new Teacher();
        teacher.setUser(user);
        teacher.setPosition("Преподаватель");
        teacherRepository.save(teacher);
        return "redirect:/users";
    }

    // Просмотр профиля пользователя
    @GetMapping("/profile")
    public String viewProfile(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/login";
        }
        model.addAttribute("user", currentUser);
        return "profile";
    }

    // Обновление профиля пользователя
    @PostMapping("/profile/update")
    public String updateProfile(@RequestParam("fullName") String fullName,
                               @RequestParam(value = "password", required = false) String password,
                               HttpSession session,
                               Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/login";
        }
        User user = userRepository.findById(currentUser.getId())
                .orElseThrow(() -> new IllegalArgumentException("Пользователь не найден"));
        user.setFullName(fullName);
        if (password != null && !password.isEmpty()) {
            user.setPassword(password);
        }
        userRepository.save(user);
        session.setAttribute("user", user); // обновить данные в сессии
        model.addAttribute("user", user);
        model.addAttribute("success", "Профиль успешно обновлен");
        return "profile";
    }
}