package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.*;
import com.university.teacher_load_system.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/loads")
public class TeachingLoadController {

    private final TeachingLoadService teachingLoadService;
    private final TeacherService teacherService;
    private final DisciplineService disciplineService;
    private final StudentGroupService groupService;

    public TeachingLoadController(TeachingLoadService teachingLoadService,
                                  TeacherService teacherService,
                                  DisciplineService disciplineService,
                                  StudentGroupService groupService) {
        this.teachingLoadService = teachingLoadService;
        this.teacherService = teacherService;
        this.disciplineService = disciplineService;
        this.groupService = groupService;
    }

    // Показать список нагрузки
    @GetMapping
    public String showLoads(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || (!"admin".equals(currentUser.getRole())
                && !"head_of_dept".equals(currentUser.getRole())
                && !"teacher".equals(currentUser.getRole()))) {
            return "redirect:/login";
        }

        List<TeachingLoad> loads;

        if ("teacher".equals(currentUser.getRole())) {
            // Преподаватель видит только свою нагрузку
            Teacher teacher = teacherService.findByUser(currentUser);
            if (teacher == null) {
                model.addAttribute("error", "Для вашей учетной записи не создан профиль преподавателя. Обратитесь к администратору.");
                model.addAttribute("loads", List.of());
                model.addAttribute("totalHours", 0);
                model.addAttribute("totalCompleted", 0);
                model.addAttribute("user", currentUser);
                model.addAttribute("userRole", currentUser.getRole());
                return "loads";
            }
            loads = teachingLoadService.findByTeacherId(teacher.getId());
        } else if ("head_of_dept".equals(currentUser.getRole())) {
            // Заведующий кафедрой — нагрузка по своей кафедре
            Teacher head = teacherService.findByUser(currentUser);
            loads = teachingLoadService.findByTeacherDepartment(head.getDepartment());
        } else {
            // Админ — все данные
            loads = teachingLoadService.findAll();
        }

        int totalHours = loads.stream().mapToInt(TeachingLoad::getHours).sum();
        int totalCompleted = loads.stream().mapToInt(TeachingLoad::getHoursCompleted).sum();

        model.addAttribute("loads", loads);
        model.addAttribute("totalHours", totalHours);
        model.addAttribute("totalCompleted", totalCompleted);
        model.addAttribute("user", currentUser);
        model.addAttribute("userRole", currentUser.getRole());

        return "loads";
    }

    // Форма назначения нагрузки — только для завкафа
    @GetMapping("/assign")
    public String showAssignForm(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/dashboard";
        }

        Teacher head = teacherService.findByUser(currentUser);
        List<Teacher> teachers = teacherService.findByDepartment(head.getDepartment());
        List<Discipline> disciplines = disciplineService.findAll();
        List<StudentGroup> groups = groupService.findAll();

        model.addAttribute("load", new TeachingLoad());
        model.addAttribute("teachers", teachers);
        model.addAttribute("disciplines", disciplines);
        model.addAttribute("groups", groups);

        return "admin/load-form";
    }

    // Сохранить нагрузку
    @PostMapping("/assign")
    public String assignLoad(@ModelAttribute TeachingLoad load, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        teachingLoadService.save(load);
        return "redirect:/loads";
    }

    @GetMapping("/delete/{id}")
    public String deleteLoad(@PathVariable Long id, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/dashboard";
        }

        teachingLoadService.deleteById(id);
        return "redirect:/loads";
    }
}