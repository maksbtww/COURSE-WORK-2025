package com.university.teacher_load_system.controller.api;

import com.university.teacher_load_system.entity.StudentGroup;
import com.university.teacher_load_system.service.StudentGroupService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
public class GroupApiController {

    private final StudentGroupService studentGroupService;

    public GroupApiController(StudentGroupService studentGroupService) {
        this.studentGroupService = studentGroupService;
    }

    @GetMapping("/search")
    public List<StudentGroup> searchGroups(@RequestParam String query) {
        if (query == null || query.isBlank()) {
            return studentGroupService.findAll();
        }
        return studentGroupService.findByCodeContainingIgnoreCase(query);
    }
}