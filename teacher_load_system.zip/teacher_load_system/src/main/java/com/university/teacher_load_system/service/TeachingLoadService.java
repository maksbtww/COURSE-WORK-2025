package com.university.teacher_load_system.service;

import com.university.teacher_load_system.entity.TeachingLoad;
import com.university.teacher_load_system.repository.TeachingLoadRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeachingLoadService {

    private final TeachingLoadRepository repository;

    public TeachingLoadService(TeachingLoadRepository repository) {
        this.repository = repository;
    }

    // Получить все нагрузки
    public List<TeachingLoad> findAll() {
        return repository.findAll();
    }

    // Найти нагрузку по кафедре преподавателя
    public List<TeachingLoad> findByTeacherDepartment(String department) {
        return repository.findByTeacher_Department(department);
    }

    public void save(TeachingLoad load) {
        repository.save(load);
    }

    public void updateHoursCompleted(Long loadId, int completedHours) {
        TeachingLoad load = repository.findById(loadId)
                .orElseThrow(() -> new IllegalArgumentException("Нагрузка не найдена"));
        load.setHoursCompleted(completedHours);
        repository.save(load);
    }
    public TeachingLoad findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Нагрузка не найдена"));
    }

    public List<TeachingLoad> findByTeacherDepartmentAndYear(String department, String academicYear) {
        return repository.findByTeacher_DepartmentAndAcademicYear(department, academicYear);
    }

    public List<TeachingLoad> findByTeacherIdAndYear(Long teacherId, String academicYear) {
        return repository.findByTeacher_IdAndAcademicYear(teacherId, academicYear);
    }

    public List<TeachingLoad> findByTeacherFullNameContainingIgnoreCase(String fullName) {
        return repository.findByTeacher_User_FullNameContainingIgnoreCase(fullName);
    }

    public List<TeachingLoad> findByTeacherId(Long teacherId) {
        return repository.findByTeacher_Id(teacherId);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}