package com.university.teacher_load_system.service;

import com.university.teacher_load_system.entity.Discipline;
import com.university.teacher_load_system.repository.DisciplineRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DisciplineService {

    private final DisciplineRepository repository;

    public DisciplineService(DisciplineRepository repository) {
        this.repository = repository;
    }

    public List<Discipline> findAll() {
        return repository.findAll();
    }

    public Discipline findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void save(Discipline discipline) {
        repository.save(discipline);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    public List<Discipline> findByNameContainingIgnoreCase(String name) {
        return repository.findByNameContainingIgnoreCase(name);
    }
}