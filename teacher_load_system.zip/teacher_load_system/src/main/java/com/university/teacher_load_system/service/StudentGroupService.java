package com.university.teacher_load_system.service;

import com.university.teacher_load_system.entity.StudentGroup;
import com.university.teacher_load_system.repository.StudentGroupRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentGroupService {
    private final StudentGroupRepository studentGroupRepository;

    public StudentGroupService(StudentGroupRepository studentGroupRepository) {
        this.studentGroupRepository = studentGroupRepository;
    }

    public List<StudentGroup> findAll() {
        return studentGroupRepository.findAll();
    }

    public StudentGroup findById(Long id) {
        return studentGroupRepository.findById(id).orElse(null);
    }

    public void save(StudentGroup group) {
        studentGroupRepository.save(group);
    }

    public void delete(Long id) {
        studentGroupRepository.deleteById(id);
    }

    public List<StudentGroup> findByCodeContainingIgnoreCase(String code) {
        return studentGroupRepository.findByCodeContainingIgnoreCase(code);
    }
}