package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.StudentGroup;
import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.repository.StudentGroupRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/groups")
public class GroupController {

    private final StudentGroupRepository studentGroupRepository;

    public GroupController(StudentGroupRepository studentGroupRepository) {
        this.studentGroupRepository = studentGroupRepository;
    }

    @GetMapping
    public String listGroups(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || (!"admin".equals(currentUser.getRole()) && !"head_of_dept".equals(currentUser.getRole()))) {
            return "redirect:/login";
        }

        List<StudentGroup> groups = studentGroupRepository.findAll();
        model.addAttribute("groups", groups);
        model.addAttribute("currentUser", currentUser);

        return "groups";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("group", new StudentGroup());
        return "admin/group-form";
    }

    @PostMapping("/save")
    public String saveGroup(@ModelAttribute("group") StudentGroup group) {
        studentGroupRepository.save(group);
        return "redirect:/groups";
    }

    @GetMapping("/edit")
    public String editGroupForm(@RequestParam("id") Long id, Model model) {
        StudentGroup group = studentGroupRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Группа не найдена"));
        model.addAttribute("group", group);
        return "admin/group-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteGroup(@PathVariable Long id) {
        studentGroupRepository.deleteById(id);
        return "redirect:/groups";
    }

}