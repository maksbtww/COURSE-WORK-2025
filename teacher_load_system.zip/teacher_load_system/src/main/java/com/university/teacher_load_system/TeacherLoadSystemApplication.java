package com.university.teacher_load_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherLoadSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherLoadSystemApplication.class, args);
	}

}
