package com.university.teacher_load_system.controller.api;

import com.university.teacher_load_system.entity.User;
import com.university.teacher_load_system.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserApiController {

    private final UserService userService;

    public UserApiController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/search")
    public List<User> searchUsers(@RequestParam String query) {
        if (query == null || query.isBlank()) {
            return userService.findAll();
        }
        return userService.findByFullNameContainingIgnoreCase(query);
    }
}