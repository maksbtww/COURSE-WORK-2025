package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.*;
import com.university.teacher_load_system.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/loads")
public class LoadTrackingController {

    private final TeachingLoadService teachingLoadService;
    private final TeacherService teacherService;
    private final DisciplineService disciplineService;
    private final StudentGroupService groupService;

    public LoadTrackingController(TeachingLoadService teachingLoadService,
                                TeacherService teacherService,
                                DisciplineService disciplineService,
                                StudentGroupService groupService) {
        this.teachingLoadService = teachingLoadService;
        this.teacherService = teacherService;
        this.disciplineService = disciplineService;
        this.groupService = groupService;
    }

    // Показать форму обновления выполненных часов
    @GetMapping("/track")
    public String showTrackForm(@RequestParam("id") Long id,
                                Model model,
                                HttpSession session,
                                @ModelAttribute("error") String error) {
        User currentUser = (User) session.getAttribute("user");

        // Проверка прав доступа
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        Teacher head = teacherService.findByUser(currentUser);
        TeachingLoad load = teachingLoadService.findById(id);
        
        // Получаем списки для выпадающих списков
        List<Teacher> teachers = teacherService.findByDepartment(head.getDepartment());
        List<Discipline> disciplines = disciplineService.findAll();
        List<StudentGroup> groups = groupService.findAll();

        model.addAttribute("load", load);
        model.addAttribute("teachers", teachers);
        model.addAttribute("disciplines", disciplines);
        model.addAttribute("groups", groups);
        
        if (!error.isEmpty()) {
            model.addAttribute("error", error);
        }

        return "admin/load-track-form";
    }

    // Обработать обновление выполненных часов
    @PostMapping("/track")
    public String updateLoad(@RequestParam("id") Long id,
                             @RequestParam("teacherId") Long teacherId,
                             @RequestParam("disciplineId") Long disciplineId,
                             @RequestParam("groupId") Long groupId,
                             @RequestParam("type") TeachingLoad.LoadType type,
                             @RequestParam("hours") int hours,
                             @RequestParam("hoursCompleted") int hoursCompleted,
                             @RequestParam("academicYear") String academicYear,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        // Проверяем, не превышают ли выполненные часы плановые
        if (hoursCompleted > hours) {
            redirectAttributes.addFlashAttribute("error", 
                "Выполненные часы (" + hoursCompleted + ") не могут превышать плановые часы (" + hours + ")");
            return "redirect:/loads/track?id=" + id;
        }

        TeachingLoad load = teachingLoadService.findById(id);
        
        // Обновляем все поля
        Teacher teacher = teacherService.findById(teacherId);
        Discipline discipline = disciplineService.findById(disciplineId);
        StudentGroup group = groupService.findById(groupId);

        load.setTeacher(teacher);
        load.setDiscipline(discipline);
        load.setGroup(group);
        load.setType(type);
        load.setHours(hours);
        load.setHoursCompleted(hoursCompleted);
        load.setAcademicYear(academicYear);

        teachingLoadService.save(load);
        return "redirect:/loads";
    }
}