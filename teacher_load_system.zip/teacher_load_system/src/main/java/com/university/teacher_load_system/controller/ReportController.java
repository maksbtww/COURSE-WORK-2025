package com.university.teacher_load_system.controller;

import com.university.teacher_load_system.entity.*;
import com.university.teacher_load_system.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/reports")
public class ReportController {

    private final TeachingLoadService teachingLoadService;
    private final TeacherService teacherService;

    public ReportController(TeachingLoadService teachingLoadService,
                            TeacherService teacherService) {
        this.teachingLoadService = teachingLoadService;
        this.teacherService = teacherService;
    }

    // Форма отчета
    @GetMapping
    public String showReportForm(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        Teacher head = teacherService.findByUser(currentUser);
        List<Teacher> teachers = teacherService.findByDepartment(head.getDepartment());

        // ВСЕГДА передавай loads, даже если он пустой
        model.addAttribute("loads", new ArrayList<>());
        model.addAttribute("teachers", teachers);
        model.addAttribute("currentYear", "2024-2025"); // можно сделать динамически

        return "reports/report-form";
    }

    // Получение отчета
    @PostMapping
    public String generateReport(@RequestParam(required = false) Long teacherId,
                                 @RequestParam String academicYear,
                                 Model model,
                                 HttpSession session) {
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return "redirect:/login";
        }

        Teacher head = teacherService.findByUser(currentUser);
        List<TeachingLoad> loads;

        if (teacherId != null && teacherId > 0) {
            loads = teachingLoadService.findByTeacherIdAndYear(teacherId, academicYear);
        } else {
            loads = teachingLoadService.findByTeacherDepartmentAndYear(head.getDepartment(), academicYear);
        }

        int totalHours = loads.stream().mapToInt(TeachingLoad::getHours).sum();
        int totalCompleted = loads.stream().mapToInt(TeachingLoad::getHoursCompleted).sum();

        model.addAttribute("loads", loads);
        model.addAttribute("totalHours", totalHours);
        model.addAttribute("totalCompleted", totalCompleted);
        model.addAttribute("academicYear", academicYear);

        model.addAttribute("teachers", teacherService.findByDepartment(head.getDepartment()));
        model.addAttribute("selectedTeacherId", teacherId);
        model.addAttribute("currentYear", academicYear);

        return "reports/report-form";
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> exportReport(@RequestParam(required = false) Long teacherId,
                                               @RequestParam String academicYear,
                                               HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null || !"head_of_dept".equals(currentUser.getRole())) {
            return ResponseEntity.status(403).build();
        }
        Teacher head = teacherService.findByUser(currentUser);
        List<TeachingLoad> loads;
        if (teacherId != null && teacherId > 0) {
            loads = teachingLoadService.findByTeacherIdAndYear(teacherId, academicYear);
        } else {
            loads = teachingLoadService.findByTeacherDepartmentAndYear(head.getDepartment(), academicYear);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Преподаватель,Дисциплина,Группа,Тип занятия,План. часы,Вып. часы,Уч. год\n");
        for (TeachingLoad load : loads) {
            sb.append('"').append(load.getTeacher().getUser().getFullName()).append('"').append(',');
            sb.append('"').append(load.getDiscipline().getName()).append('"').append(',');
            sb.append('"').append(load.getGroup().getCode()).append('"').append(',');
            sb.append('"').append(load.getType()).append('"').append(',');
            sb.append(load.getHours()).append(',');
            sb.append(load.getHoursCompleted()).append(',');
            sb.append('"').append(load.getAcademicYear()).append('"').append('\n');
        }
        byte[] csvBytes = sb.toString().getBytes(StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=report.csv")
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(csvBytes);
    }
}