package com.university.teacher_load_system.repository;

import com.university.teacher_load_system.entity.TeachingLoad;
import com.university.teacher_load_system.entity.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeachingLoadRepository extends JpaRepository<TeachingLoad, Long> {
    List<TeachingLoad> findByTeacher_Department(String department);
    List<TeachingLoad> findByTeacher_DepartmentAndAcademicYear(String department, String academicYear);
    List<TeachingLoad> findByTeacher_IdAndAcademicYear(Long teacherId, String academicYear);
    List<TeachingLoad> findByTeacher_User_FullNameContainingIgnoreCase(String fullName);
    List<TeachingLoad> findByTeacher_Id(Long teacherId);
}