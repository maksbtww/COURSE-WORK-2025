package com.university.teacher_load_system.controller.api;

import com.university.teacher_load_system.entity.Teacher;
import com.university.teacher_load_system.service.TeacherService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/teachers")
public class TeacherApiController {

    private final TeacherService teacherService;

    public TeacherApiController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @GetMapping("/search")
    public List<Teacher> searchTeachers(@RequestParam String query) {
        if (query == null || query.isBlank()) {
            return teacherService.findAll();
        }
        return teacherService.findByUserFullNameContainingIgnoreCase(query);
    }
}